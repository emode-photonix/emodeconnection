# emodeconnection

This package provides an interface to the EMode software from EMode Photonix LLC.

## Installation

`$ pip install emodeconnection`

## Using emodeconnection

See the [guide]() provided by EMode Photonix.

## License

This package is published under the 3-Clause BSD License.
